# Student Management System

A full-stack student records website for viewing, searching, creating, editing, and deleting student profiles.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/student-management/src/` — React/Vite website, routes, pages, and visual theme
- `artifacts/api-server/src/routes/students.ts` — student REST endpoints
- `lib/api-spec/openapi.yaml` — source of truth for student API contracts
- `lib/db/src/schema/students.ts` — PostgreSQL/Drizzle student schema
- `lib/api-client-react/src/generated/` — generated React Query hooks from the API contract

## Architecture decisions

- The frontend uses generated React Query hooks so requests and responses stay aligned with the OpenAPI contract.
- Student records use unique student IDs and email addresses to prevent duplicate records.
- Summary and recent-student endpoints support the dashboard without duplicating aggregation logic in the browser.
- Calendar-only enrollment dates are stored as PostgreSQL `date` values to avoid timezone shifts.

## Product

- Dashboard overview with total, active, on-leave, and graduated counts
- Searchable and filterable student directory
- Create, view, edit, and delete student records
- Client-side and server-side validation with clear success and error states

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run API codegen after editing `lib/api-spec/openapi.yaml`.
- The API server is mounted under `/api`; the website uses the generated client through the shared proxy.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
