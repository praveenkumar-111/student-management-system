import { Router, type IRouter } from "express";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { db, studentsTable } from "@workspace/db";
import {
  CreateStudentBody,
  CreateStudentResponse,
  DeleteStudentParams,
  GetRecentStudentsResponse,
  GetStudentParams,
  GetStudentResponse,
  GetStudentSummaryResponse,
  ListStudentsQueryParams,
  ListStudentsResponse,
  UpdateStudentBody,
  UpdateStudentParams,
  UpdateStudentResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toDbDate(value: Date | string | undefined): string | undefined {
  if (!value) return undefined;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return value;
}

function isUniqueViolation(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: string }).code === "23505"
  );
}

router.get("/students/summary", async (_req, res): Promise<void> => {
  const students = await db
    .select({
      course: studentsTable.course,
      status: studentsTable.status,
    })
    .from(studentsTable);

  const courses = new Map<string, number>();
  let active = 0;
  let graduated = 0;
  let onLeave = 0;

  for (const student of students) {
    courses.set(student.course, (courses.get(student.course) ?? 0) + 1);
    if (student.status === "Active") active += 1;
    if (student.status === "Graduated") graduated += 1;
    if (student.status === "On leave") onLeave += 1;
  }

  res.json(
    GetStudentSummaryResponse.parse({
      total: students.length,
      active,
      graduated,
      onLeave,
      courses: [...courses.entries()]
        .map(([course, count]) => ({ course, count }))
        .sort((a, b) => b.count - a.count),
    }),
  );
});

router.get("/students/recent", async (_req, res): Promise<void> => {
  const students = await db
    .select()
    .from(studentsTable)
    .orderBy(desc(studentsTable.id))
    .limit(5);

  res.json(GetRecentStudentsResponse.parse(students));
});

router.get("/students", async (req, res): Promise<void> => {
  const query = ListStudentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const conditions = [];
  const { search, course, status } = query.data;

  if (search) {
    const pattern = `%${search}%`;
    conditions.push(
      or(
        ilike(studentsTable.studentId, pattern),
        ilike(studentsTable.firstName, pattern),
        ilike(studentsTable.lastName, pattern),
        ilike(studentsTable.email, pattern),
      ),
    );
  }
  if (course) conditions.push(eq(studentsTable.course, course));
  if (status) conditions.push(eq(studentsTable.status, status));

  const students = await db
    .select()
    .from(studentsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(studentsTable.id));

  res.json(ListStudentsResponse.parse(students));
});

router.post("/students", async (req, res): Promise<void> => {
  const parsed = CreateStudentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = {
    ...parsed.data,
    joinedAt:
      toDbDate(parsed.data.joinedAt) ??
      new Date().toISOString().slice(0, 10),
  };

  try {
    const [student] = await db.insert(studentsTable).values(data).returning();
    res.status(201).json(CreateStudentResponse.parse(student));
  } catch (error) {
    if (isUniqueViolation(error)) {
      res
        .status(409)
        .json({ error: "Student ID or email is already registered." });
      return;
    }
    throw error;
  }
});

router.get("/students/:id", async (req, res): Promise<void> => {
  const params = GetStudentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [student] = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.id, params.data.id));

  if (!student) {
    res.status(404).json({ error: "Student not found." });
    return;
  }

  res.json(GetStudentResponse.parse(student));
});

router.patch("/students/:id", async (req, res): Promise<void> => {
  const params = UpdateStudentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateStudentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = {
    ...parsed.data,
    joinedAt: toDbDate(parsed.data.joinedAt),
  };

  try {
    const [student] = await db
      .update(studentsTable)
      .set(data)
      .where(eq(studentsTable.id, params.data.id))
      .returning();

    if (!student) {
      res.status(404).json({ error: "Student not found." });
      return;
    }

    res.json(UpdateStudentResponse.parse(student));
  } catch (error) {
    if (isUniqueViolation(error)) {
      res
        .status(409)
        .json({ error: "Student ID or email is already registered." });
      return;
    }
    throw error;
  }
});

router.delete("/students/:id", async (req, res): Promise<void> => {
  const params = DeleteStudentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [student] = await db
    .delete(studentsTable)
    .where(eq(studentsTable.id, params.data.id))
    .returning({ id: studentsTable.id });

  if (!student) {
    res.status(404).json({ error: "Student not found." });
    return;
  }

  res.sendStatus(204);
});

export default router;