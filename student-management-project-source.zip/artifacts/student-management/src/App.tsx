import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft,
  ArrowUpRight,
  BookOpen,
  Check,
  ChevronDown,
  CircleAlert,
  Clock3,
  FilePlus2,
  GraduationCap,
  LayoutDashboard,
  LoaderCircle,
  Mail,
  Menu,
  MoreHorizontal,
  Pencil,
  Phone,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
  UserRound,
  Users,
  X,
} from 'lucide-react';
import {
  getGetRecentStudentsQueryKey,
  getGetStudentQueryKey,
  getGetStudentSummaryQueryKey,
  getListStudentsQueryKey,
  type Student,
  type StudentInput,
  type StudentUpdate,
  useCreateStudent,
  useDeleteStudent,
  useGetRecentStudents,
  useGetStudent,
  useGetStudentSummary,
  useListStudents,
  useUpdateStudent,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, useLocation, useParams, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const STATUS_OPTIONS = ['Active', 'Graduated', 'On leave'] as const;
type Status = (typeof STATUS_OPTIONS)[number];
type StudentFormValues = {
  studentId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  course: string;
  year: string;
  status: Status;
  joinedAt: string;
};

const initials = (student: Pick<Student, 'firstName' | 'lastName'>) =>
  `${student.firstName[0] ?? ''}${student.lastName[0] ?? ''}`.toUpperCase();
const fullName = (student: Pick<Student, 'firstName' | 'lastName'>) =>
  `${student.firstName} ${student.lastName}`;
const formatDate = (value: string) =>
  new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(
    new Date(value),
  );
const toInputDate = (value?: string) => (value ? value.slice(0, 10) : new Date().toISOString().slice(0, 10));
const toneForStatus = (status: string) =>
  status === 'Active' ? 'status-active' : status === 'Graduated' ? 'status-graduated' : 'status-leave';

function StatusPill({ status }: { status: string }) {
  return (
    <span className={`status-pill ${toneForStatus(status)}`} data-testid={`status-${status.toLowerCase().replaceAll(' ', '-')}`}>
      <span className="status-dot" />
      {status}
    </span>
  );
}

function Avatar({ student, small = false }: { student: Pick<Student, 'firstName' | 'lastName'>; small?: boolean }) {
  return (
    <span className={`student-avatar ${small ? 'student-avatar-small' : ''}`} aria-hidden="true">
      {initials(student)}
    </span>
  );
}

function LoadingRows({ count = 5 }: { count?: number }) {
  return (
    <div className="space-y-3 p-5" data-testid="loading-state">
      {Array.from({ length: count }).map((_, index) => (
        <div className="skeleton-row" key={index}>
          <span className="skeleton-block skeleton-avatar-block" />
          <span className="skeleton-copy"><i /><i /></span>
          <span className="skeleton-block skeleton-end" />
        </div>
      ))}
    </div>
  );
}

function QueryError({ onRetry, message = 'The records could not be loaded.' }: { onRetry: () => void; message?: string }) {
  return (
    <div className="empty-state" data-testid="error-state">
      <span className="empty-icon error-icon"><CircleAlert size={20} /></span>
      <h3>Something went sideways</h3>
      <p>{message} Check your connection and try again.</p>
      <button className="btn-quiet" onClick={onRetry} data-testid="button-retry"><ArrowUpRight size={15} /> Try again</button>
    </div>
  );
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const navItems = [
    { href: '/', label: 'Overview', icon: LayoutDashboard, exact: true },
    { href: '/students', label: 'Students', icon: Users },
  ];
  return (
    <div className="app-shell app-noise">
      <aside className={`app-sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
        <div className="sidebar-topline">
          <Link href="/" className="brand" data-testid="link-brand" onClick={() => setMobileOpen(false)}>
            <span className="brand-mark"><span /></span>
            <span>keystone<span className="brand-period">.</span></span>
          </Link>
          <button className="mobile-menu-close" onClick={() => setMobileOpen(false)} aria-label="Close menu" data-testid="button-close-menu"><X size={18} /></button>
        </div>
        <div className="sidebar-workspace">
          <span className="workspace-kicker">Academic operations</span>
          <span className="workspace-name">Northbridge faculty</span>
        </div>
        <nav className="sidebar-nav" aria-label="Primary navigation">
          <span className="nav-label">Workspace</span>
          {navItems.map(({ href, label, icon: Icon, exact }) => {
            const active = exact ? location === '/' : location.startsWith(href);
            return (
              <Link
                href={href}
                key={href}
                className={`nav-link ${active ? 'nav-link-active' : ''}`}
                data-testid={`link-nav-${label.toLowerCase()}`}
                onClick={() => setMobileOpen(false)}
              >
                <Icon size={17} strokeWidth={active ? 2.3 : 1.8} />
                {label}
                {active && <span className="nav-active-mark" />}
              </Link>
            );
          })}
        </nav>
        <div className="sidebar-bottom">
          <div className="sync-card">
            <span className="sync-icon"><Check size={13} /></span>
            <div><strong>All records synced</strong><small>Updated moments ago</small></div>
          </div>
          <div className="user-chip">
            <span className="user-initial">JM</span>
            <div><strong>Jordan Mills</strong><small>Registrar</small></div>
            <MoreHorizontal size={16} className="user-more" />
          </div>
        </div>
      </aside>
      <div className="app-main">
        <header className="mobile-header">
          <button onClick={() => setMobileOpen(true)} aria-label="Open menu" data-testid="button-open-menu"><Menu size={20} /></button>
          <Link href="/" className="brand brand-mobile" data-testid="link-mobile-brand"><span className="brand-mark"><span /></span><span>keystone<span className="brand-period">.</span></span></Link>
        </header>
        {children}
      </div>
    </div>
  );
}

function PageHeader({ eyebrow, title, detail, action }: { eyebrow: string; title: ReactNode; detail: string; action?: ReactNode }) {
  return (
    <div className="page-header stagger-in">
      <div><span className="eyebrow">{eyebrow}</span><h1 className="display-title">{title}</h1><p>{detail}</p></div>
      {action && <div className="page-header-action">{action}</div>}
    </div>
  );
}

function Dashboard() {
  const summary = useGetStudentSummary();
  const recent = useGetRecentStudents();
  const summaryData = summary.data;
  return (
    <main className="page-grid">
      <PageHeader
        eyebrow="Monday, September 09, 2024"
        title={<>Know your <em>student body.</em></>}
        detail="A clear read on the people, patterns, and records that keep Northbridge moving."
        action={<Link className="btn-primary" href="/students/new" data-testid="link-add-student"><Plus size={17} /> Add student</Link>}
      />
      <section className="summary-grid stagger-in stagger-in-1" aria-label="Student summary">
        <SummaryCard label="Total students" value={summaryData?.total} icon={<Users size={19} />} tone="navy" meta="Across all programmes" loading={summary.isLoading} />
        <SummaryCard label="Active now" value={summaryData?.active} icon={<Check size={19} />} tone="mint" meta="Currently enrolled" loading={summary.isLoading} />
        <SummaryCard label="On leave" value={summaryData?.onLeave} icon={<Clock3 size={19} />} tone="peach" meta="Requires follow-up" loading={summary.isLoading} />
        <SummaryCard label="Graduated" value={summaryData?.graduated} icon={<GraduationCap size={19} />} tone="lavender" meta="Your alumni network" loading={summary.isLoading} />
      </section>
      {summary.isError ? <QueryError onRetry={() => void summary.refetch()} /> : (
        <div className="dashboard-lower">
          <section className="panel course-panel stagger-in stagger-in-2">
            <div className="panel-heading"><div><span className="eyebrow">Distribution</span><h2>Courses at a glance</h2></div><BookOpen size={20} className="heading-icon" /></div>
            {summary.isLoading ? <LoadingRows count={4} /> : summaryData?.courses?.length ? (
              <div className="course-list">
                {summaryData.courses.slice(0, 6).map((course, index) => {
                  const max = Math.max(...summaryData.courses.map((item) => item.count), 1);
                  return <div className="course-row" key={course.course} data-testid={`row-course-${index}`}>
                    <div className="course-row-label"><span>{course.course}</span><strong className="data-mono">{String(course.count).padStart(2, '0')}</strong></div>
                    <div className="course-track"><span style={{ width: `${(course.count / max) * 100}%` }} /></div>
                  </div>;
                })}
              </div>
            ) : <div className="compact-empty">No course distribution yet.</div>}
          </section>
          <section className="panel recent-panel stagger-in stagger-in-3">
            <div className="panel-heading"><div><span className="eyebrow">The latest</span><h2>Recently added</h2></div><Link href="/students" className="text-link" data-testid="link-view-all">View all <ArrowUpRight size={15} /></Link></div>
            {recent.isError ? <QueryError onRetry={() => void recent.refetch()} /> : recent.isLoading ? <LoadingRows count={4} /> : recent.data?.length ? (
              <div className="recent-list">
                {recent.data.slice(0, 5).map((student) => <Link href={`/students/${student.id}`} className="recent-row" key={student.id} data-testid={`link-recent-${student.id}`}>
                  <Avatar student={student} small /><span className="recent-name"><strong>{fullName(student)}</strong><small>{student.course}</small></span><span className="recent-date">{formatDate(student.joinedAt)}</span><ArrowUpRight size={15} className="row-arrow" />
                </Link>)}
              </div>
            ) : <EmptyState icon={<UserRound size={19} />} title="No new students yet" detail="New records will appear here." />}
          </section>
        </div>
      )}
    </main>
  );
}

function SummaryCard({ label, value, icon, tone, meta, loading }: { label: string; value?: number; icon: ReactNode; tone: string; meta: string; loading?: boolean }) {
  return <article className={`summary-card summary-${tone}`} data-testid={`card-summary-${label.toLowerCase().replaceAll(' ', '-')}`}>
    <div className="summary-top"><span className="summary-icon">{icon}</span><span className="summary-label">{label}</span></div>
    {loading ? <span className="summary-loading" /> : <strong className="summary-value data-mono">{value ?? '—'}</strong>}
    <span className="summary-meta">{meta}</span>
  </article>;
}

function EmptyState({ icon, title, detail, action }: { icon: ReactNode; title: string; detail: string; action?: ReactNode }) {
  return <div className="empty-state" data-testid="empty-state"><span className="empty-icon">{icon}</span><h3>{title}</h3><p>{detail}</p>{action}</div>;
}

function StudentsPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<Status | ''>('');
  const [course, setCourse] = useState('');
  const params = useMemo(() => ({ ...(search ? { search } : {}), ...(status ? { status } : {}), ...(course ? { course } : {}) }), [search, status, course]);
  const students = useListStudents(params);
  const deleteStudent = useDeleteStudent();
  const client = useQueryClient();
  const [selected, setSelected] = useState<Student | null>(null);
  const [notice, setNotice] = useState('');
  const courses = useMemo(() => Array.from(new Set((students.data ?? []).map((student) => student.course))).sort(), [students.data]);
  const clearFilters = () => { setSearch(''); setStatus(''); setCourse(''); };
  const handleDelete = () => {
    if (!selected) return;
    deleteStudent.mutate({ id: selected.id }, {
      onSuccess: () => {
        setNotice(`${fullName(selected)} was removed from the student records.`);
        setSelected(null);
        void client.invalidateQueries({ queryKey: getListStudentsQueryKey(params) });
        void client.invalidateQueries({ queryKey: getGetStudentSummaryQueryKey() });
        void client.invalidateQueries({ queryKey: getGetRecentStudentsQueryKey() });
      },
    });
  };
  return (
    <main className="page-grid">
      <PageHeader eyebrow="Records / Directory" title={<>The student <em>directory.</em></>} detail="Search, review, and maintain every student record from one dependable place." action={<Link className="btn-primary" href="/students/new" data-testid="link-add-student"><Plus size={17} /> Add student</Link>} />
      {notice && <div className="notice-bar" role="status" data-testid="status-delete-confirmation"><Check size={16} /> {notice}<button onClick={() => setNotice('')} aria-label="Dismiss notification" data-testid="button-dismiss-notice"><X size={15} /></button></div>}
      <section className="panel directory-panel stagger-in stagger-in-1">
        <div className="directory-toolbar">
          <div className="search-wrap"><Search size={17} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name, ID, or email" data-testid="input-search-students" /></div>
          <div className="filter-wrap"><SlidersHorizontal size={15} /><select value={status} onChange={(event) => setStatus(event.target.value as Status | '')} data-testid="select-status-filter"><option value="">All statuses</option>{STATUS_OPTIONS.map((item) => <option key={item} value={item}>{item}</option>)}</select><ChevronDown size={15} /></div>
          <div className="filter-wrap course-filter"><BookOpen size={15} /><select value={course} onChange={(event) => setCourse(event.target.value)} data-testid="select-course-filter"><option value="">All courses</option>{courses.map((item) => <option value={item} key={item}>{item}</option>)}</select><ChevronDown size={15} /></div>
          {(search || status || course) && <button className="clear-filter" onClick={clearFilters} data-testid="button-clear-filters">Clear filters</button>}
        </div>
        {students.isError ? <QueryError onRetry={() => void students.refetch()} /> : students.isLoading ? <LoadingRows count={6} /> : students.data?.length ? (
          <div className="table-scroll"><table className="student-table"><thead><tr><th>Student</th><th>Student ID</th><th>Course</th><th>Year</th><th>Status</th><th>Joined</th><th><span className="sr-only">Actions</span></th></tr></thead>
            <tbody>{students.data.map((student) => <tr key={student.id} data-testid={`row-student-${student.id}`}>
              <td><Link href={`/students/${student.id}`} className="table-student" data-testid={`link-student-${student.id}`}><Avatar student={student} small /><span><strong>{fullName(student)}</strong><small>{student.email}</small></span></Link></td>
              <td className="data-mono muted-cell">{student.studentId}</td><td>{student.course}</td><td className="year-cell">{student.year}</td><td><StatusPill status={student.status} /></td><td className="muted-cell">{formatDate(student.joinedAt)}</td>
              <td><button className="table-more" onClick={() => setSelected(student)} aria-label={`Open actions for ${fullName(student)}`} data-testid={`button-actions-${student.id}`}><MoreHorizontal size={18} /></button></td>
            </tr>)}</tbody></table></div>
        ) : <EmptyState icon={<Search size={19} />} title="No students match that search" detail="Try a different name, course, or status." action={<button className="btn-quiet" onClick={clearFilters} data-testid="button-reset-search">Reset search</button>} />}
      </section>
      <div className="directory-footer"><span>{students.data?.length ?? 0} records shown</span><span className="data-mono">LIVE DIRECTORY</span></div>
      {selected && <ConfirmDialog student={selected} pending={deleteStudent.isPending} onCancel={() => setSelected(null)} onConfirm={handleDelete} />}
    </main>
  );
}

function ConfirmDialog({ student, pending, onCancel, onConfirm }: { student: Student; pending: boolean; onCancel: () => void; onConfirm: () => void }) {
  return <div className="dialog-backdrop" role="presentation"><div className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-title">
    <button className="dialog-close" onClick={onCancel} aria-label="Close dialog" data-testid="button-close-dialog"><X size={17} /></button>
    <span className="dialog-danger-icon"><Trash2 size={19} /></span><span className="eyebrow">Remove student</span><h2 id="delete-title">Remove {student.firstName}?</h2><p>This permanently deletes <strong>{fullName(student)}</strong> and their record. This action cannot be undone.</p>
    <div className="dialog-actions"><button className="btn-quiet" onClick={onCancel} data-testid="button-cancel-delete">Keep record</button><button className="btn-primary delete-action" disabled={pending} onClick={onConfirm} data-testid="button-confirm-delete">{pending ? <LoaderCircle size={16} className="spin" /> : <Trash2 size={16} />} Remove record</button></div>
  </div></div>;
}

function StudentFormPage({ mode }: { mode: 'new' | 'edit' }) {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const isEdit = mode === 'edit';
  const studentQuery = useGetStudent(id, { query: { enabled: isEdit && Number.isFinite(id), queryKey: getGetStudentQueryKey(id) } });
  const [form, setForm] = useState<StudentFormValues>(() => ({ studentId: '', firstName: '', lastName: '', email: '', phone: '', course: '', year: '1', status: 'Active', joinedAt: toInputDate() }));
  const [initialized, setInitialized] = useState(false);
  const [formError, setFormError] = useState('');
  const [saved, setSaved] = useState(false);
  const [, setLocation] = useLocation();
  const client = useQueryClient();
  const createStudent = useCreateStudent();
  const updateStudent = useUpdateStudent();
  useEffect(() => {
    if (isEdit && studentQuery.data && !initialized) {
      const student = studentQuery.data;
      setForm({ studentId: student.studentId, firstName: student.firstName, lastName: student.lastName, email: student.email, phone: student.phone ?? '', course: student.course, year: String(student.year), status: student.status, joinedAt: toInputDate(student.joinedAt) });
      setInitialized(true);
    }
  }, [initialized, isEdit, studentQuery.data]);
  if (isEdit && studentQuery.isLoading && !initialized) return <main className="page-grid"><LoadingRows count={6} /></main>;
  if (isEdit && studentQuery.isError) return <main className="page-grid"><QueryError onRetry={() => void studentQuery.refetch()} /></main>;
  const setField = (field: keyof StudentFormValues, value: string) => setForm((current) => ({ ...current, [field]: value }));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    setFormError('');
    if (!form.studentId || !form.firstName || !form.lastName || !form.email || !form.course) { setFormError('Complete the required fields before saving.'); return; }
    const data = { studentId: form.studentId.trim(), firstName: form.firstName.trim(), lastName: form.lastName.trim(), email: form.email.trim(), phone: form.phone.trim() || null, course: form.course.trim(), year: Number(form.year), status: form.status, joinedAt: form.joinedAt } as StudentInput & StudentUpdate;
    const onSuccess = (student: Student) => {
      setSaved(true);
      void client.invalidateQueries({ queryKey: getListStudentsQueryKey() });
      void client.invalidateQueries({ queryKey: getGetStudentSummaryQueryKey() });
      void client.invalidateQueries({ queryKey: getGetRecentStudentsQueryKey() });
      if (!isEdit) setTimeout(() => setLocation(`/students/${student.id}`), 450);
    };
    if (isEdit) updateStudent.mutate({ id, data: data as StudentUpdate }, { onSuccess });
    else createStudent.mutate({ data: data as StudentInput }, { onSuccess });
  };
  const pending = createStudent.isPending || updateStudent.isPending;
  return <main className="page-grid">
    <Link href={isEdit ? `/students/${id}` : '/students'} className="back-link stagger-in" data-testid="link-back-students"><ArrowLeft size={15} /> Back to {isEdit ? 'record' : 'directory'}</Link>
    <PageHeader eyebrow={isEdit ? 'Student record / Edit' : 'Student records / New'} title={isEdit ? <>Edit <em>{form.firstName || 'student'}.</em></> : <>Add a new <em>student.</em></>} detail={isEdit ? 'Keep this record accurate so every team sees the same student story.' : 'Start with the essentials. You can update the record whenever the story changes.'} />
    <form className="form-layout stagger-in stagger-in-1" onSubmit={submit} data-testid={`form-student-${mode}`}>
      <section className="panel form-panel"><div className="form-section-heading"><span className="step-number">01</span><div><h2>Identity</h2><p>The details people use to find this record.</p></div></div>
        <div className="form-grid"><Field label="Student ID" required value={form.studentId} onChange={(value) => setField('studentId', value)} placeholder="e.g. NB-2024-014" testId="input-student-id" /><Field label="First name" required value={form.firstName} onChange={(value) => setField('firstName', value)} placeholder="Amina" testId="input-first-name" /><Field label="Last name" required value={form.lastName} onChange={(value) => setField('lastName', value)} placeholder="Okafor" testId="input-last-name" /><Field label="Email" required type="email" value={form.email} onChange={(value) => setField('email', value)} placeholder="amina@northbridge.edu" testId="input-email" /><Field label="Phone" value={form.phone} onChange={(value) => setField('phone', value)} placeholder="+1 555 000 0000" testId="input-phone" /></div>
      </section>
      <section className="panel form-panel"><div className="form-section-heading"><span className="step-number">02</span><div><h2>Academic details</h2><p>Where this student is in their Northbridge journey.</p></div></div>
        <div className="form-grid"><Field label="Course" required value={form.course} onChange={(value) => setField('course', value)} placeholder="Computer Science" testId="input-course" /><div><label className="field-label" htmlFor="input-year">Year <span className="required-mark">*</span></label><select className="field-input" id="input-year" value={form.year} onChange={(event) => setField('year', event.target.value)} data-testid="input-year">{[1, 2, 3, 4, 5, 6].map((year) => <option key={year} value={year}>Year {year}</option>)}</select></div><div><label className="field-label" htmlFor="input-status">Status <span className="required-mark">*</span></label><select className="field-input" id="input-status" value={form.status} onChange={(event) => setField('status', event.target.value)} data-testid="input-status">{STATUS_OPTIONS.map((item) => <option value={item} key={item}>{item}</option>)}</select></div><div><label className="field-label" htmlFor="input-joined-at">Joined date</label><input className="field-input" id="input-joined-at" type="date" value={form.joinedAt} onChange={(event) => setField('joinedAt', event.target.value)} data-testid="input-joined-at" /></div></div>
      </section>
      {formError && <div className="form-error" data-testid="status-form-error"><CircleAlert size={16} /> {formError}</div>}
      {saved && <div className="form-success" data-testid="status-form-success"><Check size={16} /> Record {isEdit ? 'updated' : 'created'} successfully.</div>}
      <div className="form-actions"><Link className="btn-quiet" href={isEdit ? `/students/${id}` : '/students'} data-testid="link-cancel-student">Cancel</Link><button className="btn-primary" type="submit" disabled={pending} data-testid="button-save-student">{pending ? <LoaderCircle size={16} className="spin" /> : <Check size={16} />} {isEdit ? 'Save changes' : 'Create record'}</button></div>
    </form>
  </main>;
}

function Field({ label, required, value, onChange, placeholder, type = 'text', testId }: { label: string; required?: boolean; value: string; onChange: (value: string) => void; placeholder: string; type?: string; testId: string }) {
  return <div><label className="field-label" htmlFor={testId}>{label} {required && <span className="required-mark">*</span>}</label><input className="field-input" id={testId} type={type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} data-testid={testId} /></div>;
}

function StudentDetail() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const student = useGetStudent(id, { query: { queryKey: getGetStudentQueryKey(id) } });
  if (student.isLoading) return <main className="page-grid"><LoadingRows count={6} /></main>;
  if (student.isError || !student.data) return <main className="page-grid"><QueryError onRetry={() => void student.refetch()} message="This student record could not be found." /></main>;
  const record = student.data;
  return <main className="page-grid">
    <Link href="/students" className="back-link stagger-in" data-testid="link-back-directory"><ArrowLeft size={15} /> Back to directory</Link>
    <div className="detail-hero stagger-in stagger-in-1"><div className="detail-identity"><Avatar student={record} /><div><span className="eyebrow">Student record</span><h1 className="display-title">{fullName(record)}</h1><p className="data-mono">{record.studentId}</p></div></div><div className="detail-actions"><StatusPill status={record.status} /><Link className="btn-primary" href={`/students/${record.id}/edit`} data-testid="link-edit-student"><Pencil size={15} /> Edit record</Link></div></div>
    <div className="detail-grid stagger-in stagger-in-2"><section className="panel detail-panel"><div className="panel-heading"><div><span className="eyebrow">Contact</span><h2>How to reach them</h2></div><Mail size={19} className="heading-icon" /></div><div className="contact-list"><ContactRow icon={<Mail size={17} />} label="Email address" value={record.email} /><ContactRow icon={<Phone size={17} />} label="Phone number" value={record.phone || 'Not provided'} muted={!record.phone} /></div></section><section className="panel detail-panel"><div className="panel-heading"><div><span className="eyebrow">Academics</span><h2>Their Northbridge path</h2></div><GraduationCap size={20} className="heading-icon" /></div><div className="academic-facts"><Fact label="Course" value={record.course} /><Fact label="Current year" value={`Year ${record.year}`} /><Fact label="Joined" value={formatDate(record.joinedAt)} /></div></section></div>
  </main>;
}

function ContactRow({ icon, label, value, muted }: { icon: ReactNode; label: string; value: string; muted?: boolean }) {
  return <div className="contact-row"><span className="contact-icon">{icon}</span><div><span>{label}</span><strong className={muted ? 'muted-cell' : ''}>{value}</strong></div></div>;
}
function Fact({ label, value }: { label: string; value: string }) { return <div className="fact"><span>{label}</span><strong>{value}</strong></div>; }

function Router() {
  return <ErrorBoundary resetKey={window.location.pathname}><AppShell><Switch><Route path="/" component={Dashboard} /><Route path="/students" component={StudentsPage} /><Route path="/students/new"><StudentFormPage mode="new" /></Route><Route path="/students/:id/edit"><StudentFormPage mode="edit" /></Route><Route path="/students/:id" component={StudentDetail} /><Route component={NotFound} /></Switch></AppShell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></QueryClientProvider>;
}

export default App;