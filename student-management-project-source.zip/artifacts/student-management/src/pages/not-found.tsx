import { AlertCircle } from 'lucide-react';
import { Link } from 'wouter';

export default function NotFound() {
  return (
    <div className="min-h-[100dvh] w-full flex items-center justify-center bg-background p-6">
      <div className="soft-panel w-full max-w-md rounded-[14px] p-8 text-center">
        <span className="empty-icon error-icon mx-auto"><AlertCircle size={20} /></span>
        <span className="eyebrow">Keystone / 404</span>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-foreground" data-testid="text-not-found-title">That page moved.</h1>
        <p className="mt-3 text-sm leading-6 text-muted-foreground">The record or view you’re looking for isn’t in this workspace.</p>
        <Link href="/" className="btn-primary mt-6" data-testid="link-not-found-home">Return to overview</Link>
      </div>
    </div>
  );
}
